Carpeta con el contenido para el usuario deaw.
